import subprocess
import sys
import os
import json
import tkinter as tk
from tkinter import ttk, messagebox
import requests
import platform
import tempfile
import time

def print_step(msg):
    print(f"🔧 {msg}")

def print_done():
    print("✅ Done.")

def print_error(msg):
    print(f"❌ {msg}")

def install_python():
    """Install Python if not available"""
    if platform.system() == "Windows":
        print_step("Downloading Python installer...")
        try:
            import urllib.request
            python_url = "https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
            installer_path = os.path.join(tempfile.gettempdir(), "python-installer.exe")
            urllib.request.urlretrieve(python_url, installer_path)
            
            print_step("Installing Python...")
            subprocess.run([installer_path, "/quiet", "InstallAllUsers=0", "PrependPath=1"], check=True)
            os.remove(installer_path)
            print_done()
            return True
        except Exception as e:
            print_error(f"Failed to install Python: {e}")
            return False
    else:
        print_error("Automatic Python installation only supported on Windows")
        return False

def check_python():
    """Check if Python is installed"""
    try:
        result = subprocess.run([sys.executable, "--version"], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Python found: {result.stdout.strip()}")
            return True
    except:
        pass
    
    try:
        result = subprocess.run(["python", "--version"], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Python found: {result.stdout.strip()}")
            return True
    except:
        pass
    
    print_error("Python not found. Installing...")
    return install_python()

def create_virtual_env(venv_dir):
    """Create virtual environment"""
    if not os.path.exists(venv_dir):
        print_step("Creating virtual environment...")
        subprocess.run([sys.executable, "-m", "venv", venv_dir], check=True)
    else:
        print_step("Virtual environment already exists.")
    print_done()

def install_dependencies(venv_dir):
    """Install required packages"""
    pip_path = os.path.join(venv_dir, 'Scripts', 'pip.exe') if platform.system() == "Windows" else os.path.join(venv_dir, 'bin', 'pip')
    
    print_step("Installing required packages...")
    packages = ["requests"]
    
    if platform.system() == "Windows":
        packages.append("pywin32")
    else:
        packages.append("pycups")  # For Linux printer detection
    
    for package in packages:
        print(f"Installing {package}...")
        result = subprocess.run([pip_path, "install", package], capture_output=True, text=True)
        if result.returncode != 0:
            print_error(f"Failed to install {package}: {result.stderr}")
            messagebox.showerror("Error", f"Failed to install {package}. Please check your internet connection.")
            return False
    
    print_done()
    return True

def detect_printers():
    """Detect available printers on the system"""
    printers = []
    
    if platform.system() == "Windows":
        try:
            import win32print
            printer_list = win32print.EnumPrinters(2)
            printers = [printer[2] for printer in printer_list if printer[2].strip()]
            print(f"✅ Found {len(printers)} Windows printers")
        except ImportError:
            print_error("win32print not found.")
            messagebox.showerror("Error", "Windows printer detection failed. pywin32 not properly installed.")
            return []
        except Exception as e:
            print_error(f"Error detecting Windows printers: {e}")
            return []
    
    elif platform.system() == "Linux":
        try:
            import cups
            conn = cups.Connection()
            printer_dict = conn.getPrinters()
            printers = list(printer_dict.keys())
            print(f"✅ Found {len(printers)} Linux printers")
        except ImportError:
            print_error("pycups not found.")
            messagebox.showerror("Error", "Linux printer detection failed. pycups not properly installed.")
            return []
        except Exception as e:
            print_error(f"Error detecting Linux printers: {e}")
            return []
    
    return printers

def get_dealer_id_gui():
    """GUI to get dealer ID from user"""
    def submit():
        try:
            dealer_id = entry.get().strip()
            if not dealer_id:
                raise ValueError("Dealer ID cannot be empty")
            result.set(dealer_id)
            root.quit()
        except ValueError as e:
            messagebox.showerror("Error", str(e))
    
    def on_closing():
        messagebox.showwarning("Warning", "Dealer ID is required to continue.")
        root.quit()
        sys.exit(1)
    
    root = tk.Tk()
    root.title("QR Printer Setup - Dealer ID")
    root.geometry("450x250")
    root.resizable(False, False)
    
    # Center window
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - (450 // 2)
    y = (root.winfo_screenheight() // 2) - (250 // 2)
    root.geometry(f"450x250+{x}+{y}")
    
    root.protocol("WM_DELETE_WINDOW", on_closing)
    
    frame = ttk.Frame(root, padding="20")
    frame.pack(fill=tk.BOTH, expand=True)
    
    ttk.Label(frame, text="Good Way Express", font=("Arial", 16, "bold")).pack(pady=5)
    ttk.Label(frame, text="QR Printer Setup", font=("Arial", 12)).pack(pady=5)
    ttk.Label(frame, text="Enter Your Dealer ID", font=("Arial", 12, "bold")).pack(pady=10)
    ttk.Label(frame, text="(This should be provided by Good Way Express)").pack(pady=5)
    
    entry = ttk.Entry(frame, font=("Arial", 11), width=25)
    entry.pack(pady=10)
    entry.focus()
    
    ttk.Button(frame, text="Continue", command=submit).pack(pady=10)
    
    result = tk.StringVar()
    
    def on_enter(event):
        submit()
    
    entry.bind('<Return>', on_enter)
    
    root.mainloop()
    root.destroy()
    return result.get()

def load_dealer_id():
    """Load dealer ID from config file or prompt user"""
    config_path = os.path.join(os.getcwd(), "dealer_config.json")
    
    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as f:
                data = json.load(f)
                dealer_id = data.get("dealer_id")
                if dealer_id and str(dealer_id).strip():
                    print(f"✅ Loaded dealer_id from config: {dealer_id}")
                    return str(dealer_id).strip()
        except (json.JSONDecodeError, FileNotFoundError):
            pass
    
    print("❌ Dealer ID not found or invalid. Prompting user...")
    dealer_id = get_dealer_id_gui()
    
    # Save dealer ID
    try:
        with open(config_path, "w") as f:
            json.dump({"dealer_id": dealer_id}, f, indent=2)
        print(f"✅ Saved dealer_id to config: {dealer_id}")
    except Exception as e:
        print(f"⚠️ Could not save dealer_id: {e}")
    
    return dealer_id

def send_to_server(dealer_id, printers):
    """Send printer list to Django server"""
    url = "http://147.93.110.231/dealer/api/save_printers/"
    payload = {
        "client_id": dealer_id,
        "printers": printers
    }
    
    try:
        print_step(f"Sending {len(printers)} printers to server...")
        response = requests.post(url, json=payload, timeout=30)
        
        if response.status_code == 200:
            response_data = response.json()
            print("✅ Printer configuration sent to server successfully!")
            dealer_name = response_data.get("dealer_name", "Unknown")
            messagebox.showinfo(
                "Success", 
                f"Setup Complete!\n\n"
                f"Dealer: {dealer_name}\n"
                f"Dealer ID: {dealer_id}\n"
                f"Printers Detected: {len(printers)}\n\n"
                f"You can now configure QR printing on the website:\n"
                f"http://147.93.110.231/dealer/qr-printer-setting/"
            )
            return True
        else:
            print_error(f"Server responded with: {response.status_code}")
            print(f"Response: {response.text}")
            messagebox.showerror(
                "Server Error", 
                f"Failed to send printer data to server.\n"
                f"Status: {response.status_code}\n"
                f"Please try again or contact support."
            )
            return False
            
    except requests.exceptions.Timeout:
        print_error("Request timed out")
        messagebox.showerror("Timeout", "Connection to server timed out. Please check your internet connection and try again.")
        return False
    except requests.exceptions.ConnectionError:
        print_error("Connection error")
        messagebox.showerror("Connection Error", "Cannot connect to server. Please check your internet connection and try again.")
        return False
    except Exception as e:
        print_error(f"Failed to connect to server: {str(e)}")
        messagebox.showerror("Error", f"Failed to send data to server: {str(e)}")
        return False

def show_completion_message(dealer_id, printers):
    """Show completion message with next steps"""
    def open_website():
        import webbrowser
        webbrowser.open("http://147.93.110.231/dealer/qr-printer-setting/")
        root.quit()
    
    def close_app():
        root.quit()
    
    root = tk.Tk()
    root.title("Setup Complete - Good Way Express")
    root.geometry("500x400")
    root.resizable(False, False)
    
    # Center window
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - (500 // 2)
    y = (root.winfo_screenheight() // 2) - (400 // 2)
    root.geometry(f"500x400+{x}+{y}")
    
    frame = ttk.Frame(root, padding="20")
    frame.pack(fill=tk.BOTH, expand=True)
    
    ttk.Label(frame, text="🎉 Setup Complete!", font=("Arial", 16, "bold")).pack(pady=10)
    ttk.Label(frame, text="QR Printer setup has been completed successfully.", font=("Arial", 12)).pack(pady=5)
    
    # Summary
    summary_frame = ttk.LabelFrame(frame, text="Summary", padding="10")
    summary_frame.pack(fill=tk.X, pady=10)
    
    ttk.Label(summary_frame, text=f"Dealer ID: {dealer_id}", font=("Arial", 10)).pack(anchor=tk.W)
    ttk.Label(summary_frame, text=f"Printers Detected: {len(printers)}", font=("Arial", 10)).pack(anchor=tk.W)
    
    if printers:
        ttk.Label(summary_frame, text="Detected Printers:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(10,0))
        for printer in printers[:5]:  # Show first 5 printers
            ttk.Label(summary_frame, text=f"• {printer}", font=("Arial", 9)).pack(anchor=tk.W, padx=10)
        if len(printers) > 5:
            ttk.Label(summary_frame, text=f"... and {len(printers)-5} more", font=("Arial", 9)).pack(anchor=tk.W, padx=10)
    
    # Next steps
    next_frame = ttk.LabelFrame(frame, text="Next Steps", padding="10")
    next_frame.pack(fill=tk.X, pady=10)
    
    ttk.Label(next_frame, text="1. Click 'Open Website' below", font=("Arial", 10)).pack(anchor=tk.W)
    ttk.Label(next_frame, text="2. Select your QR printer from the dropdown", font=("Arial", 10)).pack(anchor=tk.W)
    ttk.Label(next_frame, text="3. Start using QR printing for your CNotes", font=("Arial", 10)).pack(anchor=tk.W)
    
    # Buttons
    button_frame = ttk.Frame(frame)
    button_frame.pack(pady=20)
    
    ttk.Button(button_frame, text="Open Website", command=open_website).pack(side=tk.LEFT, padx=5)
    ttk.Button(button_frame, text="Close", command=close_app).pack(side=tk.LEFT, padx=5)
    
    root.mainloop()
    root.destroy()

def main():
    """Main setup function"""
    print("🚀 Starting One-Click QR Printer Setup for Good Way Express...\n")
    
    try:
        # Check Python installation
        if not check_python():
            print_error("Python installation failed. Please install Python manually and try again.")
            messagebox.showerror("Error", "Python installation failed. Please install Python manually from python.org and try again.")
            sys.exit(1)
        
        # Setup paths
        venv_dir = os.path.join(os.getcwd(), 'venv')
        
        # Create virtual environment and install dependencies
        create_virtual_env(venv_dir)
        if not install_dependencies(venv_dir):
            sys.exit(1)
        
        # Add venv to path for imports
        if platform.system() == "Windows":
            venv_site_packages = os.path.join(venv_dir, 'Lib', 'site-packages')
        else:
            # Find the correct Python version directory
            python_version = f"python{sys.version_info.major}.{sys.version_info.minor}"
            venv_site_packages = os.path.join(venv_dir, 'lib', python_version, 'site-packages')
        
        sys.path.insert(0, venv_site_packages)
        
        # Get dealer ID
        print_step("Getting dealer ID...")
        dealer_id = load_dealer_id()
        print(f"➡️ Dealer ID: {dealer_id}")
        
        # Detect printers
        print_step("Detecting system printers...")
        printers = detect_printers()
        
        if not printers:
            print("⚠️ No printers found on system.")
            messagebox.showwarning(
                "No Printers Found", 
                "No printers detected on your system.\n\n"
                "Please:\n"
                "1. Connect and install your printer\n"
                "2. Make sure it's turned on\n"
                "3. Run this setup again\n\n"
                "The setup will continue to register your dealer ID."
            )
        else:
            print(f"✅ Found {len(printers)} printers")
        
        # Send to server
        success = send_to_server(dealer_id, printers)
        
        if success:
            print("\n🎉 Setup completed successfully!")
            show_completion_message(dealer_id, printers)
        else:
            print("\n❌ Setup completed with errors.")
            messagebox.showerror("Error", "Setup completed with errors. Please try running the setup again or contact support.")
        
    except KeyboardInterrupt:
        print("\n❌ Setup cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        messagebox.showerror("Error", f"Setup failed with error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()