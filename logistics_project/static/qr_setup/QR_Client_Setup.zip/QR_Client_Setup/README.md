# QR Printer Setup Tool - Good Way Express

यह tool आपके system के printers को automatically detect करता है और Good Way Express के साथ QR label printing के लिए configure करता है।

## Quick Start (तुरंत शुरू करें)

1. **Download** करें यह folder अपने computer पर
2. **Double-click** करें `run_setup.bat` (Windows) या run करें `python setup.py` (Linux/Mac)
3. **Follow करें prompts** - अपना Dealer ID enter करें
4. **Done!** आपका printer अब QR printing के लिए configured है

## यह Tool क्या करता है

- ✅ Automatically Python install करता है अगर जरूरत हो
- ✅ Isolated environment बनाता है dependencies के लिए
- ✅ आपके system के सभी printers को detect करता है
- ✅ आपका printer selection Good Way Express server को भेजता है
- ✅ आपके dealer account के लिए QR printing configure करता है

## System Requirements

- **Windows 10/11** (recommended) या **Linux**
- **Internet connection** initial setup के लिए
- **Connected printer** (USB, Network, या Bluetooth)

## Supported Printer Types

- Thermal label printers (58mm recommended for QR labels)
- Inkjet/Laser printers (A4 layout use करेंगे)
- Network printers
- USB printers

## Troubleshooting

### "No printers found"
- Make sure आपका printer connected है और on है
- Check करें कि printer drivers installed हैं
- Try करें test page print Windows settings से

### "Failed to install Python"
- Run करें as Administrator
- Download करें Python manually https://python.org से
- Make sure आपका internet connection है

### "Cannot connect to server"
- Check करें आपका internet connection
- Verify करें कि server URL accessible है
- Try करें again कुछ minutes बाद

### "Permission denied"
- Right-click करें `run_setup.bat` और select करें "Run as Administrator"
- Make sure आपको permission है software install करने की

## Files Included

- `setup.py` - Main setup script
- `run_setup.bat` - Windows batch file for easy execution
- `requirements.txt` - Python dependencies
- `README.md` - यह file

## Support

अगर आपको कोई issues आती हैं:

1. Check करें error messages console में
2. Try करें running as Administrator
3. Ensure करें कि आपका printer properly installed है
4. Contact करें Good Way Express support अपने Dealer ID के साथ

## Technical Details

- Uses `win32print` for Windows printer detection
- Uses `pycups` for Linux printer detection
- Sends printer data to Django API endpoint
- Creates virtual environment to avoid conflicts
- Stores dealer configuration locally in `dealer_config.json`

## Next Steps

Setup complete होने के बाद:

1. Visit करें: http://147.93.110.231/dealer/qr-printer-setting/
2. Select करें अपना QR printer dropdown से
3. Start करें QR printing अपने CNotes के लिए

---

**Good Way Express** - Making logistics simple and efficient!